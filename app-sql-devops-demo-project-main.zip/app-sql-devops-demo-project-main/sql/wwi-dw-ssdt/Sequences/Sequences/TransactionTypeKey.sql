﻿CREATE SEQUENCE [Sequences].[TransactionTypeKey]
    AS INT
    START WITH 1
    INCREMENT BY 1;

