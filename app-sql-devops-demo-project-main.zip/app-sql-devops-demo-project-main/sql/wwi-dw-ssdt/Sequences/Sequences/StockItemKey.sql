﻿CREATE SEQUENCE [Sequences].[StockItemKey]
    AS INT
    START WITH 1
    INCREMENT BY 1;

